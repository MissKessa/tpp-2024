﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp
{
    internal class Program
    {
        static void ApplyAction<T>(IEnumerable<T> e, Action<T> a) {
            foreach (T item in e)
            {
                a(item);
            }
        }

        static void LocalApplyAction<Tl>(IEnumerable<Tl> sequence, Action<Tl> a, IEnumerator<Tl> enumerator) {
            if (enumerator.MoveNext())
            {
                a(enumerator.Current);
                LocalApplyAction(sequence, a, enumerator);
            }
        }

        static void ApplyAction2<T>(IEnumerable<T> e, Action<T> a)
        {
            IEnumerator<T> enumerator = e.GetEnumerator();
            LocalApplyAction(e, a, enumerator);
        }

        static int Count<T>(IEnumerable<T> v, Predicate<T> p)
        {
            int count = 0;
            foreach (T item in v)
            {
                if (p(item)) count++;
            }
            return count;
        }

        static int Count2<T>(IEnumerable<T> v, Predicate<T> p)
        {
            IList<int> counter = new List<int>() { 0 };
            Action<int> action = delegate (int x)
            {
                x++;
            };

            foreach (T item in v)
            {
                if (p(item)) ApplyAction(counter, action);
            }
            return counter[0];
        }

        static int FindFirst<T>(IEnumerable<T> v, Predicate<T> p)
        {
            for (int i = 0; i < v.Count(); i++)
            {
                if (p(v.ElementAt(i))) {
                    return i;
                }
            }
            return -1;
        }

        static Func<double, double> ComposeDouble(Func<double, double> f, Func<double, double> g)
        {
            Func<double, double> a = (double x) => f(g(x));
            return a;
        }
        //static Func<T,G> ComposeG(Func<T, G> g, Func<M , T> f) 
        //{
        //    Func<M, G> a = (M x) => g(f(x));
        //    return a;
        //}

        static int Increment(int x) { x++; return x; }
        static int ToInt(char x) { return (int)x; }
        static char ToChar(int x) { return (char)x; }

        static bool Exists(IEnumerable<int> v, Predicate<int> p)
        {
            foreach (int x in v)
            {
                if (p(x)) return true;
            }
            return false;
        }


        static void Main(string[] args)
        {
            Ejer1();
            Ejer2();
            Ejer3();
        }

        static void Ejer1()
        {
            Func<double, double> asinh = (double x) => (Math.Log10(x + Math.Sqrt(Math.Pow(x, 2) + 1)));
            Func<double, double> acosh = (double x) => (Math.Log10(x + Math.Sqrt(Math.Pow(x, 2) - 1)));
            Func<double, double> atanh = (double x) => ((Math.Log10(1 + x) - Math.Log(1 - x)) / 2);
        }

        static void Ejer2()
        {
            IList<int> ints = new List<int>() { 1, 2, 3, 4, 5 };
            IList<char> chars = new List<char>() { 'a', 'b', 'c', 'd', 'e' };
            ApplyAction(ints, x => Console.Write($"{x}"));
            Console.WriteLine();
            ApplyAction(chars, x => Console.Write($"{x}"));
        }

        static void Ejer3()
        {
            IList<int> ints = new List<int>() { 1, 2, 3, 4, 5 };
            IList<char> chars = new List<char>() { 'a', 'b', 'c', 'd', 'e' };

            Predicate<int> isEven = x => x % 2 == 0;

            Predicate<int> isPrime = delegate (int x)
            {
                for (int i = 2; i < x; i++) {
                    if (x % i == 0)
                        return false;
                }
                return true;
            };
            Console.WriteLine();
            Console.WriteLine(Count(ints, isEven));
            Console.WriteLine(Count(ints, isPrime));
        }

        static void Ejer4()
        {
            IList<int> primes = new List<int>() { 2 };

            Predicate<int> IsPrime = delegate (int x)
            {
                int i = x + 1;
                while (i % x == 0) { i++; }
                return i;
            };

            

        }
    }
}
