﻿using System;
using System.Collections.Generic;

namespace Lab_1_Assignment
{
    internal class Program
    {

        static void Main(string[] args)
        {
            List l2 = new List();
            Console.WriteLine(l2.toString());
            l2.printAllElements();

            List l = new List(1);

            Console.WriteLine(l.toString());
            l.printAllElements();

            l.add(2);
            Console.WriteLine(l.toString());
            l.printAllElements();

            l.add(3);
            Console.WriteLine(l.toString());
            l.printAllElements();

            l.add(1);
            Console.WriteLine(l.toString());
            l.printAllElements();

            l.remove(1);
            Console.WriteLine(l.toString());
            l.printAllElements();

            l.remove(3);
            Console.WriteLine(l.toString());
            l.printAllElements();

            l.remove(1);
            Console.WriteLine(l.toString());
            l.printAllElements();

            l.remove(2);
            Console.WriteLine(l.toString());
            l.printAllElements();
        }
    }
}
