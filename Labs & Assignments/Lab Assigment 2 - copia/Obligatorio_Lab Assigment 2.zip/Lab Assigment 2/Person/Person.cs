﻿using System;
using LinkedList;

namespace TPP.ObjectOrientation.Overload
{   public class Person : IComparable
    {
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public string IDNumber { get; set; }

        public Person(int age=0, String name="A", String surname="B", String id="1")
        {
            Age = age;
            FirstName = name;
            Surname = surname;
            IDNumber = id;
        }


        public int CompareTo(Object other)
        {
            if(other is Person)
            {
                Person p = (Person)other;
                return IDNumber.CompareTo(p.IDNumber);
            }
            throw new ArgumentException("You cannot compare a Person with another type");
        }

        public override bool Equals(object obj)
        {
            if (CompareTo(obj) == 0)
            {
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            return string.Format("{0} {1}, age:{2}, id:{3}", this.FirstName, this.Surname, this.Age,
                  this.IDNumber);
        }

        
    }
}

